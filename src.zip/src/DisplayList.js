import React, {Component} from 'react';

class DisplayList extends Component {
  renderList() {
    const items = this.props.items.map(list => {
      return (
        <div xs ={10} md = {10}>
        <h1>
        {list.name}
        </h1>
          <img src={list.img}/>
        </div>
      )
    });

    return items;
  }

  render() {
    return (
      <ul class = "grid">
        {this.renderList()}
      </ul>
    );
  }
}

export default DisplayList;
