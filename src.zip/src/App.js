import React, { Component } from "react";
import logo from './logo.svg';
import './App.css';
import FilteredList from "./FilteredList";
import ReactDOM from 'react-dom';
import RangeRover from "./range\ rover.png"
import Mercedes from "./mercedes.png"
import Honda from "./honda\ civic.png"
import Toyota from "./toyota\ corolla.jpg"
import Lexus from "./lexus.png"
import Bmw from "./bmw.png"
import Nissan from "./nissan\ leaf.jpg"
import Hyundai from "./hyundai\ accent.jpg"
import Tesla from "./tesla.png"
import Porsche from "./porsche\ cayenne.png"
import Kia from "./kia\ rio.png"
import Chevrolet from "./chevrolet\ sonic.png"


//<img src="({require(./tesla.png)}">




const productList = [
  //need to filter by size too
 { name: "Range Rover", manufacturer: "Land Rover", type: "Luxury", img: RangeRover, price: 100, size: "SUV", icon:   <button class="btn"><div  style={{color: 'blue'}}>

     </div></button>},
 { name: "Mercedes Benz", manufacturer: "Mercedes", type: "Luxury", img: Mercedes, price: 40000, size: "small"},
 { name: "Honda Civic", manufacturer: "Honda", type: "Affordable", img: Honda, price: 20000, size: "small"},
 { name: "Toyota Corolla", manufacturer: "Toyota", type: "Affordable", img: Toyota, price: 19000, size: "small"},
 { name: "Lexus", manufacturer: "Toyota", type: "Luxury", img: Lexus, price: 39000, size: "SUV"},
 { name: "BMW X5", manufacturer: "BMW", type: "Luxury", img: Bmw, price: 410000, size: "SUV"},
 { name: "Nissan Leaf", manufacturer: "Nissan", type: "Affordable", img: Nissan, price: 30000, size: "small"},

 { name: "Hyundai Accent", manufacturer: "Hyundai", type: "Affordable", img: Hyundai, price: 15000, size: "small"},
 { name: "Tesla Model X", manufacturer: "Tesla", type: "Luxury", img: Tesla, price:80000, size: "small"},
 { name: "Porsche Cayenne", manufacturer: "Porsche", type: "Luxury", img: Porsche, price: 50000, size: "SUV"},
 { name: "Kia Rio", manufacturer: "Kia", type: "Affordable", img: Kia, price: 15000, size: "small"},
 { name: "Chevrolet Sonic", manufacturer: "Chevrolet", type: "Affordable", img: Chevrolet, price: 16000, size: "small"},

];



class App extends React.Component {
  render() {
  return (
    <div className="App">
    <h2> Welcome</h2>
      <img src = {RangeRover} width = "500" alt="rangerover"/>
      <img src = {Mercedes} width = "500" alt="mercedes"/>
      <img src = {Honda} width = "500" alt="honda"/>
      <img src = {Toyota} width = "500" alt="toyota"/>
      <img src = {Lexus} width = "500" alt="lexus"/>
      <img src = {Bmw} width = "500" alt="bmw"/>
      <img src = {Nissan} width = "500" alt="nissan"/>
      <img src = {Hyundai} width = "500" alt="hyundai"/>
      <img src = {Tesla} width = "500" alt="tesla"/>
      <img src = {Porsche} width = "500" alt="porsche"/>
      <img src = {Kia} width = "500" alt="kia"/>
      <img src = {Chevrolet} width = "500" alt="Chevrolet"/>

      <FilteredList items = {productList}/>


    </div>
  );
}
}

export default App;
