import React, { Component } from "react";
import { DropdownButton, Dropdown } from "react-bootstrap";
import { InputLabel, Select, MenuItem } from "@material-ui/core";
//import { connect } from 'react-redux'
//import { Link } from 'react-router-dom'
//import { removeItem,addQuantity,subtractQuantity} from './actions/cartActions'
import DisplayList from "./DisplayList";

class FilteredList extends Component {
  constructor(props) {
    super(props);
    this.state = {
    type: "All",
    size: "All", //do in app.js too
    sort: "All",
    items: this.props.items

  //  totalPrice: 0
    };
  }

  // onAggregatorAdd = list => {
  //   this.setState({ totalPrice: event.target.value });
  //   totalPrice += list.price;
  //   //add item to shoppingcart array
  //
  //   return {
  //     list,
  //     totalPrice
  //   }
  // }
  //
  // onAggregatorRemove= list => {
  //   this.setState({ totalPrice: event.target.value });
  //   totalPrice -= list.price;
  //   //remove item from shoppingcart array
  //
  //   return {
  //     list,
  //     totalPrice
  //   }
  // }

//   handleAddQuantity = (id)=>{
//          this.props.addQuantity(id);
//      }
//
//      handleSubtractQuantity = (id)=>{
//       this.props.subtractQuantity(id);
//   }
//
//   handleRemove = (id)=>{
//          this.props.removeItem(id);
//      }
//
//   onClick={()=>{this.handleClick(item.id)}}
//
//   handleClick = (id)=>{
// this.props.addToCart(id);
// }

//made a list called shopping cart list and put that in my State
//total price variable integer and put that in my state
//addtoaggregator - modifies the state, takes in an item and increments the total price varaiable by the price of the item
// also adds item to shopping cart list
//removefromaggregator - does the opposite
//renders to display list
//the other displaylist is set to be your shopping cart list
//have to parse the helper functions (add and remove from aggregator) to both of your display lists

//have to parse your adding and removing from

  onSelectFilterType = event => {
    this.setState({ type:  event.target.value });
  };

  onSelectFilterSize = event => {
    this.setState({ size: event.target.value });
  };


  matchesFilterType = list => {
    if(this.state.type === "All"){
      return true;
    }
    else if(this.state.type === list.type) {
      return true;
    }
    else {
      return false;
    }
  }

  matchesFilterSize = list => {
    if(this.state.size === "All") {
      return true;
    }
    else if(this.state.size === list.size) {
      return true;
    }
    else {
      return false;
    }
  }


  onSort = event => {
    this.setState({ sort: event });
  };

  sortOptions = (list1, list2) => {
    console.log(this.state.sort)
    if (this.state.sort === "All") {
      return 0;
    }
    else if (this.state.sort === "price") {

      return list1.price - list2.price;
    }
  }

  qStyle ={
    marginRight: "3vw",
  }

fStyle = {
  display: "flex", width: "60%", flexDirection: "row", padding: "1vw", flexWrap: "wrap",
};



  render() {
    return (
    <div>
    <form margin="normal" style={this.qStyle}>
    <div style={this.qStyle}>
    <InputLabel>Filter Size:</InputLabel>
    <Select onChange={this.onSelectFilterSize} style ={{margin: '15px'}} defaultValue={"All"}>
    <MenuItem value= "" disabled>Size</MenuItem>
    <MenuItem value={"All"}>All</MenuItem>
    <MenuItem value={"small"}>Small</MenuItem>
    <MenuItem value={"SUV"}>SUV</MenuItem>
    </Select>
    </div>

    <div style={this.qStyle}>
    <InputLabel>Filter Type:</InputLabel>
    <Select onChange={this.onSelectFilterType} style ={{margin: '15px'}} defaultValue={"All"}>
    <MenuItem value= "" disabled>Type</MenuItem>
    <MenuItem value={"All"}>All</MenuItem>
    <MenuItem value={"Luxury"}>Luxury</MenuItem>
    <MenuItem value={"Affordable"}>Affordable</MenuItem>
    </Select>

    <div style={this.qStyle}>
    <InputLabel>Sort by:</InputLabel>
    <Select onChange={this.onSort} style ={{margin: '15px'}} defaultValue={"All"}>
    <MenuItem value= "" disabled>Sorting</MenuItem>
    <MenuItem value={"All"}>All</MenuItem>
    <MenuItem value={"price"}>price</MenuItem>

    </Select>

</div>
    </div>

    </form>
    <DisplayList items={this.state.items.filter(this.matchesFilterSize).filter(this.matchesFilterType).sort(this.sortOptions)} />

    </div>


  //  <p> Size: {this.state.size} </p>
  //      <DisplayList items={this.props.items.filter(this.matchesFilterSize)} />
      // </div>


  );
  }


}
export default FilteredList;
